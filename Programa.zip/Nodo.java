public class Nodo {
    String dato;
    Nodo siguiente;
}
