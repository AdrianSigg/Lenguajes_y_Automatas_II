import java.util.*;

public class Identificador {
  //Se crea una arraylist donde se guardará la cadena caracter por caracter
  ArrayList<Character> cadenaChar = new ArrayList<Character>();
  //Pilas donde se guardarán las cadenas encontradas por sublenguaje
  PilaA ciclos = new PilaA();
  PilaA delimitadores = new PilaA();
  PilaA operadores = new PilaA();
  PilaA reservadas = new PilaA();
  PilaA escape = new PilaA();

  Scanner teclado = new Scanner(System.in);
  //Se crea un alfabeto, es la clase donde se define el lenguaje
  Alfabeto alfa = new Alfabeto();
  //Se crean las expresiones regulares
  ExpresionesRegulares exre = new ExpresionesRegulares();
  //Variable donde se guarda la cadena completa
  String cadena = "";
  //Variable donde se guarda la cadena por partes
  String[] split;
  //Iteradores que se utilizaran
  int iteradorC =0, iteradorI=0, iteradorO=0, iteradorR=0, iteradorE=0;

  //Se muestra un mensaje en pantalla que explica el programa
  void info(){
    String mensaje = "";
    mensaje = "Programa que permite introducir una cadena, verificarla\n";
    mensaje+= "y comprobar si pertenece al alfabeto propuesto, así\n";
    mensaje+= "como mostrar a qué sublenguaje pertenece\n";
    mensaje += "e imprimir su expresión regular\n";
    System.out.println(mensaje);
  }

  //Método para ingresar datos
  void datos(){
    System.out.println("Introduzca la cadena a verificar");
    cadena = teclado.nextLine();
  }

  //Método donde se guardan los datos
  void guardarDatos(){
    //Se ingresa la cadena a una listaArreglo para leerla caracter por caracter
    for (int i = 0; i < cadena.length(); i++) cadenaChar.add(cadena.charAt(i));
    //Se separa la cadena cada que haya un espacio y se guarda
    split = cadena.split(" ");
  }
  //Se valida el alfabeto
  boolean validarAlfabeto(){
    /*Se eliminan todos los caracteres iguales en la lista cadenaChar a 
    excepcion de los que no se contiene, así se puede saber si ingresaron
    una que no pertenece al alfabeto*/
    cadenaChar.removeAll(alfa.alfabeto);
    /*Se comprueba, si cadenaChar tiene al menos un dato, significa que hay un
    caracter no comprendido en el alfabeto*/
    if (cadenaChar.size()==0) return true;
    return false;
  }

  //Valida si la cadena proporcionada contiene algún ciclo de nuestro lenguaje
  void validarCiclos(){
    for (int i = 0; i < alfa.ciclos.size(); i++)
      for (int j = 0; j < split.length; j++) 
        /*Si nuestro sublenguaje contiene una cadena igual a la de la cadena
        proporcionada, se inserta en la pila correspondiente y se 
        aumenta el contador para saber cuántas cadenas hay en la pila*/
        if (alfa.ciclos.get(i).equals(split[j])) {
          ciclos.insert(split[j]);
          iteradorC++;
        }
  }

  //Valida si la cadena contiene algún Delimitador de nuestro lenguaje
  void validarDelimitadores() {
    for (int i = 0; i < alfa.delimitadores.size(); i++)
      for (int j = 0; j < split.length; j++)
        if (alfa.delimitadores.get(i).equals(split[j].charAt(0))) {
          delimitadores.insert(split[j]);
          iteradorI++;
        }
  }

  //Valida si la cadena contiene algún Operador de nuestro lenguaje
  void validarOperadores() {
    for (int i = 0; i < alfa.operadores.size(); i++)
      for (int j = 0; j < split.length; j++)
        if (alfa.operadores.get(i).equals(split[j])) {
          operadores.insert(split[j]);
          iteradorO++;
        }
  }

  // Valida si la cadena contiene alguna palabra reservada de nuestro lenguaje
  void validarPalabrasRes() {
    for (int i = 0; i < alfa.reservadas.size(); i++)
      for (int j = 0; j < split.length; j++)
        if (alfa.reservadas.get(i).equals(split[j])) {
          reservadas.insert(split[j]);
          iteradorR++;
        }
  }

  //Valida si la cadena contiene alguna secuencia de escape de nuestro lenguaje
  void validarSecuenciaE() {
    for (int i = 0; i < alfa.escape.size(); i++)
      for (int j = 0; j < split.length; j++)
        if (alfa.escape.get(i).equals(split[j])) {
          escape.insert(split[j]);
          iteradorE++;
        }
  }

  //Método para imprimir los resultados
  void resultado(){
    //Se crean cadenas solo para no pasar las 80 columnas en el programa
    String si,no;
    si = "Todos los caracteres forman parte del alfabeto\n";
    no = "La cadena ingresada tiene un ";
    no += "caracter que no forma parte del alfabeto\n";
    /*Si la validacion del alfabeto devuelve true imprime que el caracter
    forma parte del alfabeto, de otro modo imprime que hay un caracter que no
    forma parte de el*/
    if (validarAlfabeto()) System.out.println(si);
    else System.out.println(no);

    //Imprime todos los ciclos encontrados en la cadena sólo si hay
    if (iteradorC>0){
      System.out.println("-------Ciclos-------");
      for (int i = 0; i < iteradorC; i++) 
        System.out.println(ciclos.extract()+"\n");
    }

    // Imprime todos los delimitadores encontrados en la cadena sólo si hay
    if (iteradorI > 0){
      System.out.println("------Delimitadores-------");
      for (int i = 0; i < iteradorI; i++) 
        System.out.println(delimitadores.extract() + "\n");
    }

    // Imprime todos los operadores encontrados en la cadena sólo si hay
    if (iteradorO > 0){
      System.out.println("-------Operadores---------");
      for (int i = 0; i < iteradorO; i++) 
        System.out.println(operadores.extract() + "\n");
    }

    // Imprime las palabras reservadas encontrados en la cadena sólo si hay
    if (iteradorR > 0){
      System.out.println("---------Palabras Reservadas---------");
      for (int i = 0; i < iteradorR; i++)
        System.out.println(reservadas.extract() + "\n");
    }
    
    // Imprime las secuencias de escape encontrados en la cadena sólo si hay
    if (iteradorE > 0){
      System.out.println("--------Secuencias de Escape--------");
      for (int i = 0; i < iteradorE; i++)
        System.out.println(escape.extract() + "\n");
    }
  }

  void imprimeER(){
    System.out.println("============Expresiones Regulares================");
    for (int i = 0; i < split.length; i++) {
      if (exre.libER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Definición de biblioteca");
        System.out.println("Expresión Regular: " + exre.biblio);
        System.out.println("---------------------------------------------");
      }
      if (exre.varER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Variables");
        System.out.println("Expresion Regular: " + exre.Variable);
        System.out.println("---------------------------------------------");
      }
      if (exre.constCharER(split[i])) {
        System.out.println("Palabra: "+split[i]);
        System.out.println("Clasificación: Constante de caracter");
        System.out.println("Expresión Regular: "+exre.constanteC);
        System.out.println("---------------------------------------------");
      }
      if (exre.asigER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Asignación");
        System.out.println("Expresión Regular: " + exre.asignacion);
        System.out.println("---------------------------------------------");
      }
      if (exre.metodoER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Declaración de un método");
        System.out.println("Expresión Regular: " + exre.metodo);
        System.out.println("---------------------------------------------");
      }
      if (exre.repER(split[i])) {
        String repString = "Repetir<iterador,condicion,incremento>{expresion}";
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Ciclo Repetir");
        System.out.println("Expresión Regular: " + repString);
        System.out.println("---------------------------------------------");
      }
      if (exre.mientER(split[i])) {
        String mienString = "Mientras<Condición>{Expresión}";
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Ciclo Mientras");
        System.out.println("Expresión Regular:" + mienString);
        System.out.println("---------------------------------------------");
      }
      if (exre.hazER(split[i])) {
        String hazString = "Haz {Expresión} Mientras <Condición>";
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Ciclo Haz-Mientras");
        System.out.println("Expresión Regular: " + hazString);
        System.out.println("---------------------------------------------");
      }
      if (exre.condicER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Condicionales");
        System.out.println("Expresión Regular: "+exre.condicion);
        System.out.println("---------------------------------------------");
      }
      if (exre.impER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Palabra Reservada");
        System.out.println("Expresión Regular: "+exre.imprime);
        System.out.println("---------------------------------------------");
      }
      if (exre.escER(split[i])) {
        System.out.println("Palabra: " + split[i]);
        System.out.println("Clasificación: Secuencia de escape");
        System.out.println("Expresión Regular: "+exre.escape);
        System.out.println("---------------------------------------------");
      }
    }
  }
  //Método main
  public static void main(String[] args) {
    Identificador obj = new Identificador();

    obj.info();
    obj.datos();
    obj.guardarDatos();
    obj.validarCiclos();
    obj.validarDelimitadores();
    obj.validarOperadores();
    obj.validarPalabrasRes();
    obj.validarSecuenciaE();
    obj.resultado();
    obj.imprimeER();
  }
} 